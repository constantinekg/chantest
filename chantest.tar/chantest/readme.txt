Created by Constantine 7.7.2015
http://infdots.blogspot.com
myainetwork@gmail.com

This script working for system online checking.
Please run this script with -h parameter to see all functions.
